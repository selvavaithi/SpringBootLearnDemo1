package com.javaspringcloudtestdemo.JavaSpringCloudTestDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaSpringCloudTestDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
